# Mango Health Project

A web application about common pests and diseases affecting mango trees.

## Installation Guide

1. Open Terminal/Command Prompt
2. Navigate to the project folder:
   ```
   cd path\to\mango_project # Windows
   cd /path/to/mango_project # Mac/Linux
   ```
3. Create a Virtual Environment
   ```
   python -m venv venv
   venv\Scripts\activate # Windows
   source venv/bin/activate # Mac/Linux
   ```
4. Install Required Packages
   ```
   pip install -r requirements.txt
   ```

## Running the Project

1. Ensure the virtual environment is activated
2. Run the server:
   ```
   python manage.py runserver
   ```
3. You will see: "Starting development server at http://127.0.0.1:8000/"


## Using the Website

1. **Home Page**: The main landing page of the website
2. **Pests & Diseases**: Click this in the navigation bar to see all pests and diseases
3. **Pest Details**: Click on any pest or disease to see more information
4. **About**: Information about the project and team

## Stopping the Server

1. Go back to the Terminal/Command Prompt
2. Press `Ctrl + C` (Windows/Linux) or `Cmd + C` (Mac)
3. Type `Y` and press Enter to confirm
