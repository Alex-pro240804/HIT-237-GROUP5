class PestDisease:
    def __init__(self, name, type, short_details, description, image_name):
        self.name = name
        self.type = type
        self.short_details = short_details
        self.description = description
        self.image_name = image_name